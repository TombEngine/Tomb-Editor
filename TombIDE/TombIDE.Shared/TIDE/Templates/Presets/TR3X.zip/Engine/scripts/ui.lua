-- The colours text is drawn in where it names none.
require("common.ui.accent").setup()

-- The fades the screens share, and how a level comes in.
require("common.ui.fade").setup()
require("common.ui.level_start").setup()

-- The lines of text, the arrows and the ring hints that the game asks for
-- over the play.
require("common.ui.captions").setup()
require("common.ui.ring_hints").setup()

-- The screens the interface draws in place of the engine's.
require("common.ui.menu").setup()
require("common.ui.controls_model").setup()
require("common.ui.screens.combine").setup()
require("common.ui.screens.examine").setup()
require("common.ui.screens.globe").setup()
require("common.ui.screens.level_view").setup()
require("common.ui.screens.passport").setup()
require("common.ui.screens.picture").setup()
require("common.ui.screens.settings").setup()
require("common.ui.screens.stats").setup()
