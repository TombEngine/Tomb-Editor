#include "common.glsl"

// How deep a band TR4 takes the water's color up over, in world units.
#define WATER_LINE_FEATHER 16.0

// The values that change from one instance to the next, one slot per
// instance. A batch holds many instances, and each of its vertices names the
// slot of its own; every other draw holds its one instance in slot 0.
struct Instance {
    mat4 model;
    vec4 tint;
    // x = whether a water surface cuts the instance, y = the world height of
    // that surface, z = the water effect, w = whether the water wibbles the
    // instance. A fragment below the line takes the tint; one above it does
    // not, so a mesh that straddles the surface is split where the water is
    // rather than taken whole.
    vec4 water;
    vec4 waterParams; // x = choppy amp, y = shimmer amp, z = abs intensity
    // xyz = how far the ambient light below the water line shifts, w =
    // whether it shifts at all. A water room and a dry room differ in their
    // ambient light alone, so the shift relights the submerged part and
    // leaves the point lights and the texture as they are.
    vec4 submerged;
    // xyz = the ambient at the far end of a mesh that spans two rooms, w =
    // whether one spans them at all. A joint's vertices carry how far they
    // sit towards the mesh they reach for, so the light runs across the joint
    // rather than stepping at the seam.
    vec4 ambientSpan;
    vec4 room; // x = light mode
    // The light of the instance, laid out as its game's lighting family
    // says.
    vec4 light[7];
};

layout(std140) uniform Instances {
    Instance uInstances[MAX_INSTANCES];
};

int gSlot;

#define I_MAT_MODEL uInstances[gSlot].model
#define I_TINT uInstances[gSlot].tint
#define I_WATER_LINE_ENABLED (uInstances[gSlot].water.x != 0.0)
#define I_WATER_LINE uInstances[gSlot].water.y
#define I_WATER_EFFECT int(uInstances[gSlot].water.z)
#define I_WIBBLE_EFFECT (uInstances[gSlot].water.w != 0.0)
#define I_WATER_EFFECT_PARAMS uInstances[gSlot].waterParams.xyz
#define I_SUBMERGED_AMBIENT_ENABLED (uInstances[gSlot].submerged.w != 0.0)
#define I_SUBMERGED_AMBIENT_DELTA vec4(uInstances[gSlot].submerged.xyz, 0.0)
#define I_AMBIENT_SPAN_ENABLED (uInstances[gSlot].ambientSpan.w != 0.0)
#define I_AMBIENT_SPAN_FROM vec4(uInstances[gSlot].ambientSpan.xyz, 1.0)
#define I_ROOM_LIGHT_MODE int(uInstances[gSlot].room.x)
#define I_LIGHT(n) uInstances[gSlot].light[n]

// One definition of what the mesh stages hand each other. The geometry stage
// is optional, so the vertex stage names its block after whichever stage reads
// it: a block is matched across stages by its name, and a stage cannot declare
// an input block and an output block under one name.
#define MESH_VARYINGS             \
    vec4 eyePos;                  \
    vec3 normal;                  \
    flat uint flags;              \
    flat int texLayer;            \
    vec2 texUV;                   \
    flat vec4 atlasSize;          \
    vec2 trapezoidRatios;         \
    vec4 color;                   \
    vec3 add;                     \
    float tintWeight;             \
    float worldY;                 \
    vec3 colorSub;                \
    vec3 addSub;                  \
    flat float reflectivity;      \
    noperspective vec4 affineUV;  \
    flat int slot;

#ifdef SUBDIVIDE
    #define MESH_VS_BLOCK VertexData
#else
    #define MESH_VS_BLOCK GeomData
#endif

#ifdef VERTEX

#include "billboard.glsl"
#include "lights.glsl"

layout(location = 0) in vec4 aPosition;
layout(location = 1) in vec4 aNormal;
layout(location = 2) in vec3 aUVW;
layout(location = 3) in vec4 aTextureSize;
layout(location = 4) in vec2 aTrapezoidRatios;
layout(location = 5) in uint aFlags;
layout(location = 6) in vec4 aColor;
layout(location = 7) in float aShade;
layout(location = 8) in float aReflectivity;
layout(location = 9) in vec2 aUVScroll; // x = V per game frame, y = wrap
layout(location = 10) in float aTintFactor;

// Where the draw takes its vertices from. A batch draws the faces of many
// instances at once. Its gl_VertexID holds a vertex of the mesh buffers,
// counted from uVertexBase, in the low 24 bits and the slot of its instance
// in the high bits, and the vertex is read from the buffers rather than from
// the attributes.
uniform bool uPullVertices;
uniform int uVertexBase;
uniform usamplerBuffer uGeomData;
// The same buffer as uGeomData, read as unsigned normalized bytes, so that
// the color converts to float as the attribute would.
uniform samplerBuffer uGeomColors;
uniform usamplerBuffer uTexData;
uniform usamplerBuffer uShadeData;

// How many 32-bit words a vertex takes in each mesh buffer. Matches
// M_MESH_GEOM, M_MESH_TEXTURE and M_MESH_SHADE in
// src/trx/game/output/mesh_batcher/batcher.c.
#define GEOM_WORDS 11
#define TEX_WORDS 12
#define SHADE_WORDS 1

vec4 inPosition;
vec4 inNormal;
vec3 inUVW;
vec4 inTextureSize;
vec2 inTrapezoidRatios;
uint inFlags;
vec4 inColor;
float inShade;
float inReflectivity;
vec2 inUVScroll;
float inTintFactor;

float fetchFloat(usamplerBuffer data, int word)
{
    return uintBitsToFloat(texelFetch(data, word).r);
}

vec2 fetchVec2(usamplerBuffer data, int word)
{
    return vec2(fetchFloat(data, word), fetchFloat(data, word + 1));
}

vec4 fetchVec4(usamplerBuffer data, int word)
{
    return vec4(
        fetchFloat(data, word), fetchFloat(data, word + 1),
        fetchFloat(data, word + 2), fetchFloat(data, word + 3));
}

void loadVertex(void)
{
    if (!uPullVertices) {
        gSlot = 0;
        inPosition = aPosition;
        inNormal = aNormal;
        inUVW = aUVW;
        inTextureSize = aTextureSize;
        inTrapezoidRatios = aTrapezoidRatios;
        inFlags = aFlags;
        inColor = aColor;
        inShade = aShade;
        inReflectivity = aReflectivity;
        inUVScroll = aUVScroll;
        inTintFactor = aTintFactor;
        return;
    }

    uint id = uint(gl_VertexID);
    gSlot = int(id >> 24u);
    int vertex = uVertexBase + int(id & 0xFFFFFFu);

    int geom = vertex * GEOM_WORDS;
    inPosition = fetchVec4(uGeomData, geom);
    inNormal = fetchVec4(uGeomData, geom + 4);
    inColor = texelFetch(uGeomColors, geom + 8);
    inFlags = texelFetch(uGeomData, geom + 9).r & 0xFFFFu;
    inTintFactor = fetchFloat(uGeomData, geom + 10);

    int tex = vertex * TEX_WORDS;
    inUVW = vec3(
        fetchFloat(uTexData, tex), fetchFloat(uTexData, tex + 1),
        fetchFloat(uTexData, tex + 2));
    inTextureSize = fetchVec4(uTexData, tex + 3);
    inTrapezoidRatios = fetchVec2(uTexData, tex + 7);
    inReflectivity = fetchFloat(uTexData, tex + 9);
    inUVScroll = fetchVec2(uTexData, tex + 10);

    inShade = fetchFloat(uShadeData, vertex * SHADE_WORDS);
}

out MESH_VS_BLOCK {
    MESH_VARYINGS
} gOut;

vec3 gammaCurve(vec3 rgb, float gamma_exp)
{
    return pow(clamp(rgb, 0.0, 1.0), vec3(gamma_exp));
}

#if TR_VERSION >= 4
// Splits the light into the part the texture modulates and the overbright
// excess added after texturing, as the OG CalcColorSplit does. The OG engine
// lights everything in the "128 = neutral" scale: the lit value is doubled
// and the excess above 1.0 becomes the additive term.
vec3 shadeTR4(
    vec3 lightIn, vec3 modulate, vec3 lightAdd, vec3 tintReg, float gamma_exp,
    uint flags, out vec3 addOut)
{
    bool overbright = uLightingCurve == LIGHTING_CURVE_OVERBRIGHT;
    bool saturate = uLightingCurve == LIGHTING_CURVE_SATURATE;
    // An unlit color is a plain color that modulates the texture, as the OG
    // draws its effects, unless VERT_OVERBRIGHT marks it as light on the
    // 128-neutral scale.
    bool neutral_scale = uLightingEnabled == 0
        || (flags & VERT_NO_LIGHTING) == 0u
        || (flags & (VERT_FLAT_SHADED | VERT_OVERBRIGHT)) != 0u;
    vec3 L = lightIn
            * ((overbright || saturate) && neutral_scale ? 255.0 / 128.0 : 1.0)
        + lightAdd;
    addOut = overbright ? max(L - vec3(1.0), vec3(0.0)) * (64.0 / 255.0)
                        : vec3(0.0);
    // The OG draws additive polys with specular disabled (HWR_DrawSortList
    // drawtype 2). An unlit poly carries a color rather than a light value,
    // so it has no excess to split off either.
    if ((flags & (VERT_ADDITIVE | VERT_NO_LIGHTING)) != 0u) {
        addOut = vec3(0.0);
    }
    // Keeps the saturating excess past the gamma curve so texture modulation
    // clips each color channel separately, as the PlayStation does.
    L = min(L * tintReg, vec3(255.0 / 128.0));
    vec3 over = saturate ? max(L - vec3(1.0), vec3(0.0)) : vec3(0.0);
    return (gammaCurve(L, gamma_exp) + over) * modulate;
}
#endif

// Grows the distortion with the display, so that it stays visible where the
// original left it at the two pixels a 640x480 screen was given. A sharp
// screen shows the same share of the picture as a stronger distortion, so the
// growth tapers rather than tracking the height. Supersampling raises the
// render target alone and must not change what reaches the screen.
float wibbleScale(void)
{
    float ss = float(uSupersamplingFactor);
    return sqrt((uViewportSize.y / ss) / 480.0) * ss;
}

float wibbleTable(float phase, float pos, float scale)
{
    float idx =
        mod(floor(phase / 8.0 + pos / (8.0 * scale)), float(WIBBLE_SIZE));
    return float(MAX_WIBBLE) * scale * sin(idx * (2.0 * PI / float(WIBBLE_SIZE)));
}

vec3 waterWibble(vec4 worldPosition, vec4 screenPosition)
{
    vec3 ndc = screenPosition.xyz / screenPosition.w;
    vec2 pixelPos = (ndc.xy * 0.5 + 0.5) * uViewportSize;
#if TR_VERSION == 3
    float phases = (uTimeInGame * 0.5 + length(worldPosition.xyz)) * (2.0 * PI / WIBBLE_SIZE);
    pixelPos.y += sin(phases) * wibbleScale();
#elif TR_VERSION == 4
    float phase = uTimeInGame * 4.0;
    float scale = wibbleScale();
    vec2 srcPos = pixelPos;
    pixelPos.x += wibbleTable(phase, srcPos.y, scale);
    pixelPos.y += wibbleTable(phase, srcPos.x, scale);
#else
    float phases = (uTimeInGame + length(worldPosition.xyz)) * (2.0 * PI / WIBBLE_SIZE);
    float amplitude = MAX_WIBBLE * float(uSupersamplingFactor);
    pixelPos.x += sin(phases) * amplitude;
    pixelPos.y += cos(phases) * amplitude;
#endif
    // reverse transform
    ndc.xy = (pixelPos / uViewportSize - 0.5) * 2.0;
    return ndc * screenPosition.w;
}

// The PS1 GTE computed screen coordinates as integers, so vertices could only
// land on whole output pixels. Quantizing the clip position to the selected
// simulated pixel grid reproduces the wobble that geometry shows when the
// camera moves.
vec4 vertexSnap(vec4 clipPos)
{
    vec3 ndc = clipPos.xyz / clipPos.w;
    ndc.xy = floor(ndc.xy * uVertexSnapResolution * 0.5)
        / (uVertexSnapResolution * 0.5);
    return vec4(ndc * clipPos.w, clipPos.w);
}

// Returns the PlayStation depth-cue factor from eye distance. The GTE evaluates
// IR0 = DQB + DQA * (h / sz) per vertex, so the blend is linear in 1/z.
// The configured near and far distances solve DQA and DQB.
float ps1FogFactor(float dist)
{
    float near_dist = max(uFogDistance.x, 1.0);
    float far_dist = max(uFogDistance.y, near_dist + 1.0);
    float dqa = 1.0 / far_dist - 1.0 / near_dist;
    return clamp((1.0 / max(dist, 1.0) - 1.0 / near_dist) / dqa, 0.0, 1.0);
}

void main(void) {
    loadVertex();
    gOut.slot = gSlot;
    vec4 worldPos = I_MAT_MODEL * vec4(inPosition.xyz, 1.0);
    vec4 lightWorldPos = worldPos;

    // Read before the choppy displacement below, so that a vertex the water
    // moves is still cut where it rests.
    gOut.worldY = worldPos.y;

    if ((inFlags & VERT_MOVE) != 0u) {
        float waterMul = (I_WATER_EFFECT != 0) ? 1.0 : 0.0;
        worldPos.y += effectChoppy(worldPos.xyz) * waterMul;
    }

    if ((inFlags & (VERT_ABS_SPRITE | VERT_BILLBOARD)) != 0u) {
        int lockMode = (inFlags & VERT_ABS_SPRITE) != 0u ? BILLBOARD_LOCK_NONE : uBillboardLockMode;
        gOut.eyePos = offsetBillboard(inPosition.xyz, inNormal.xy, uMatView, I_MAT_MODEL, uMatProj, lockMode);
    } else {
        gOut.eyePos = uMatView * worldPos;
    }

    // Reflections are sphere-mapped, so the normal has to be in view space for
    // the reflection to track the camera - an object space normal locks it to
    // the object instead. This is what the OG does for TR4, transforming the
    // mesh normals by the view matrix. Normalize because ours arrive as raw
    // int16s rather than the unit vectors the mapping expects.
    gOut.normal = normalize(mat3(uMatView * I_MAT_MODEL) * inNormal.xyz);
    gl_Position = uMatProj * gOut.eyePos;
    gl_Position.z += inPosition.w;

    // Apply water wibble effect only to non-sprite vertices
    if (I_WIBBLE_EFFECT && (inFlags & (VERT_NO_WIBBLE | VERT_BILLBOARD)) == 0u) {
        gl_Position.xyz = waterWibble(worldPos, gl_Position);
    }

    // Sprites and billboards keep sub-pixel positioning, so that UI elements
    // and effects don't crawl.
    if (uVertexSnapEnabled != 0
        && (inFlags & (VERT_ABS_SPRITE | VERT_BILLBOARD)) == 0u) {
        gl_Position = vertexSnap(gl_Position);
    }

    gOut.flags = inFlags;
    gOut.atlasSize = inTextureSize;
    gOut.texLayer = (uTexturesEnabled != 0) && (gOut.flags & VERT_FLAT_SHADED) == 0u ? int(inUVW.z) : -1;
    gOut.trapezoidRatios = inTrapezoidRatios;
    gOut.texUV = inUVW.xy;
    if (inUVScroll.y > 0.0) {
        gOut.texUV.y += mod(uUVScrollTick * inUVScroll.x, inUVScroll.y);
    }
    gOut.reflectivity = inReflectivity;
    float fogFactor = ps1FogFactor(fogDistance(gOut.eyePos.xyz));
    if (uTrapezoidFilterEnabled != 0) {
        gOut.texUV *= inTrapezoidRatios;
    }
    gOut.affineUV = vec4(gOut.texUV, gOut.trapezoidRatios);

    // The vertex diffuse is lit first and then modulated by the texture (or by
    // the flat polygon's palette color). Keep the lighting component separate
    // from the base color so gamma is applied in the right place.
    LightingResult lr =
        light(inShade, gOut.flags, inNormal.xyz, lightWorldPos, inNormal.w);
    float shade = lr.shade;

    float gamma_exp = 1.0 / ((uGamma / 10.0) * 4.0);

    float tintWeight = 1.0;
#if TR_VERSION == 4
    if ((inFlags & (VERT_MOVE | VERT_GLOW)) != 0u) {
        tintWeight = 0.0;
    }
#endif
    gOut.tintWeight = tintWeight;

    // Applies PlayStation water tint before the gamma curve and texture
    // modulation, where the GTE combines it with the light register.
    vec3 tintReg =
        uLightingCurve == LIGHTING_CURVE_SATURATE && !I_WATER_LINE_ENABLED
        ? mix(vec3(1.0), I_TINT.rgb, tintWeight)
        : vec3(1.0);

#if TR_VERSION >= 4
    // The OG engine lights everything in the "128 = neutral" scale: the lit value is
    // doubled and the excess above 1.0 becomes an additive overbright term
    // applied after texturing (CalcColorSplit).
    vec3 lightIn;
    vec3 modulate;
    if ((gOut.flags & VERT_FLAT_SHADED) != 0u) {
        lightIn = vec3(128.0 / 255.0); // neutral: no lighting, no overbright
        modulate = inColor.rgb;
    } else if (uLightingEnabled == 0) {
        lightIn = vec3(128.0 / 255.0);
        modulate = vec3(1);
    } else {
        if ((gOut.flags & VERT_USE_OBJECT_LIGHT) != 0u) {
            lightIn = lightObjectsTR4(
                inNormal.xyz, inPosition.xyz,
                I_AMBIENT_SPAN_ENABLED
                    ? mix(I_AMBIENT_SPAN_FROM.rgb, I_TR4_AMBIENT.rgb,
                          clamp(inTintFactor, 0.0, 1.0))
                    : I_TR4_AMBIENT.rgb);
            // White for regular meshes; mesh policies may recolor vertices
            // (e.g. the skybox fog gradient faces are painted black).
            modulate = inColor.rgb;
        } else if ((gOut.flags & VERT_USE_OWN_LIGHT) != 0u) {
            lightIn = lightOwnTR4(inShade);
            modulate = inColor.rgb;
        } else {
            lightIn = inColor.rgb;
            modulate = vec3(1);
        }
    }

    vec3 add;
    vec3 lit = shadeTR4(
        lightIn, modulate, lr.add, tintReg, gamma_exp, gOut.flags, add);
    gOut.color = vec4(lit, inColor.a);
    gOut.add = add;

    // Lights the mesh a second time towards the water room, for the fragment
    // stage to take the submerged part from.
    gOut.colorSub = lit;
    gOut.addSub = add;
    if (I_SUBMERGED_AMBIENT_ENABLED
        && (gOut.flags & VERT_USE_OBJECT_LIGHT) != 0u) {
        gOut.colorSub = shadeTR4(
            lightObjectsTR4(
                inNormal.xyz, inPosition.xyz,
                I_TR4_AMBIENT.rgb + I_SUBMERGED_AMBIENT_DELTA.rgb), modulate,
            lr.add, tintReg, gamma_exp, gOut.flags, add);
        gOut.addSub = add;
    }
#elif TR_VERSION >= 3
    vec3 lightIn;
    vec3 modulate;
    if ((gOut.flags & VERT_FLAT_SHADED) == 0u) {
        if (uLightingEnabled == 0) {
            lightIn = vec3(1);
        } else {
            lightIn = inColor.rgb;
        }
        modulate = vec3(1);
    } else {
        lightIn = vec3(1);
        modulate = inColor.rgb;
    }

    // Combine lighting in linear-ish space first: (base + add) * mul
    bool saturate = uLightingCurve == LIGHTING_CURVE_SATURATE;
    vec3 lit;
    gOut.add = vec3(0.0);
    if ((gOut.flags & VERT_OVERBRIGHT) != 0u && uLightingEnabled != 0) {
        // OG "128 = neutral" lighting: inColor is a raw prelit color where
        // 128/255 means full brightness. Doubling it saturates the diffuse
        // part; the excess becomes an additive term applied after texturing
        // (tomb4's CalcColorSplit: diffuse = min(2c, 255), add = (c-128)/2).
        vec3 L = lightIn * (255.0 / 128.0) + lr.add;
        if (saturate) {
            lit = L;
        } else {
            gOut.add = max(L - vec3(1.0), vec3(0.0)) * (64.0 / 255.0);
            lit = clamp(L, 0.0, 1.0);
        }
    } else {
        vec3 L = lightIn + lr.add;
        lit = saturate ? L : clamp(L, 0.0, 1.0);
    }
    lit *= lr.mul;

    // Doubles non-overbright TR3 light only when the selected curve uses the
    // OG hardware renderer's 128-neutral scale.
    if (uLightingEnabled != 0 && (gOut.flags & VERT_OVERBRIGHT) == 0u) {
        if (saturate) {
            lit *= 255.0 / 128.0;
        } else if (uLightingCurve == LIGHTING_CURVE_OVERBRIGHT) {
            vec3 L = lit * (255.0 / 128.0);
            if ((gOut.flags & VERT_NO_LIGHTING) == 0u) {
                gOut.add += max(L - vec3(1.0), vec3(0.0)) * (64.0 / 255.0);
            }
            lit = clamp(L, 0.0, 1.0);
        }
    }

    // Keeps the saturating excess past the gamma curve.
    lit = min(lit * tintReg, vec3(255.0 / 128.0));
    vec3 over = max(lit - vec3(1.0), vec3(0.0));
    lit = gammaCurve(lit, gamma_exp) + over;

    // Apply flat shading AFTER modulation
    gOut.color = vec4(lit * modulate, inColor.a);

    // Only TR4 lights the submerged part of a mesh separately.
    gOut.colorSub = gOut.color.rgb;
    gOut.addSub = gOut.add;
#else
    gOut.add = vec3(0.0);
    float shade_mul = 1.0;
    if ((gOut.flags & VERT_NO_LIGHTING) == 0u) {
        shade_mul = (2.0 - (max(shade, uMinShade) / SHADE_NEUTRAL));
    }

    // `shade_mul` is roughly in [0..2]. Remap to [0..1], apply the gamma
    // curve, and restore the range. Use sqrt() to limit the effect scope,
    // since we're applying it to the shade (TR1-2) rather than RGB (TR3).
    vec3 mul = gammaCurve(vec3(shade_mul * 0.5), sqrt(gamma_exp)) * 2.0;

    gOut.color = inColor;
    if ((gOut.flags & VERT_FLAT_SHADED) == 0u) {
        gOut.color.rgb = gammaCurve(gOut.color.rgb, gamma_exp);
    }
    gOut.color.rgb *= mul;
    // Preserve the >1.0 lighting range until after texturing so TR1/TR2
    // high contrast can still brighten textured geometry.
    gOut.color.rgb += lr.add;
    // Only TR4 lights the submerged part of a mesh separately.
    gOut.colorSub = gOut.color.rgb;
    gOut.addSub = gOut.add;
#endif

    // Applies PlayStation depth cue before texture modulation, as tomb3's
    // transform.cpp does, so fog keeps the surface texture.
    if (uPS1FogEnabled != 0
        && (gOut.flags & (VERT_NO_FOG | VERT_NO_LIGHTING)) == 0u
        && uLightingEnabled != 0) {
        gOut.color.rgb = mix(gOut.color.rgb, uFogColor.rgb, fogFactor);
        gOut.add *= 1.0 - fogFactor;
    }
}

#elif defined(GEOMETRY)

layout(triangles) in;
layout(triangle_strip, max_vertices = 24) out;

in VertexData {
    MESH_VARYINGS
} gIn[];

out GeomData {
    MESH_VARYINGS
} gOut;

// How far, in pixels, the flat mapping puts a texel from where perspective
// would put it. Across one edge the flat mapping reaches the halfway point at
// the middle of the edge on screen, while perspective reaches it at
// w0 / (w0 + w1), and the gap between the two carries that much of the edge's
// screen length.
//
// The OG picked the split from view distance instead, at 2000 and 3500 world
// units (HWI_InsertGT4_Sorted), which it could do because it drew at one
// resolution. Those distances leave an error of about a pixel at 320x240 and
// grow with the render size, so the same numbers pop visibly once the render
// is larger. Measuring the error keeps the split where the OG put it at the
// OG's resolution, and moves it outward as the render grows.
float affineErrorPixels(void)
{
    float w0 = gl_in[0].gl_Position.w;
    float w1 = gl_in[1].gl_Position.w;
    float w2 = gl_in[2].gl_Position.w;
    float wMin = min(min(w0, w1), w2);
    float wMax = max(max(w0, w1), w2);

    // A face that reaches the eye plane has no finite size on screen. It is as
    // close as a face can be, so it takes the finest split.
    if (wMin < 1.0) {
        return 1.0e9;
    }

    vec2 p0 = gl_in[0].gl_Position.xy / w0;
    vec2 p1 = gl_in[1].gl_Position.xy / w1;
    vec2 p2 = gl_in[2].gl_Position.xy / w2;
    vec2 span = (max(max(p0, p1), p2) - min(min(p0, p1), p2)) * uViewportSize
        * 0.5;
    float extent = max(span.x, span.y);
    return extent * (wMax - wMin) / (2.0 * (wMax + wMin));
}

// Splitting a face in two halves the screen span and the depth range at once,
// so it quarters the error: a level of N leaves an Nth squared of it. The
// levels below are the ones that bring the error under a pixel.
int subdivideLevel(void)
{
    float error = affineErrorPixels();
    if (error > 4.0) {
        return 4;
    }
    if (error > 1.0) {
        return 2;
    }
    return 1;
}

// Clip space is a linear map of view space, so weighting the clip positions
// puts the new vertex where the OG's own SubdivideEdge puts it, and keeps the
// depth offset, the wibble, and the vertex snap the vertex stage applied.
void emitAt(vec3 w)
{
    gl_Position = gl_in[0].gl_Position * w.x + gl_in[1].gl_Position * w.y
        + gl_in[2].gl_Position * w.z;
    gOut.eyePos =
        gIn[0].eyePos * w.x + gIn[1].eyePos * w.y + gIn[2].eyePos * w.z;
    gOut.normal =
        gIn[0].normal * w.x + gIn[1].normal * w.y + gIn[2].normal * w.z;
    gOut.texUV =
        gIn[0].texUV * w.x + gIn[1].texUV * w.y + gIn[2].texUV * w.z;
    gOut.trapezoidRatios = gIn[0].trapezoidRatios * w.x
        + gIn[1].trapezoidRatios * w.y + gIn[2].trapezoidRatios * w.z;
    gOut.color = gIn[0].color * w.x + gIn[1].color * w.y + gIn[2].color * w.z;
    gOut.add = gIn[0].add * w.x + gIn[1].add * w.y + gIn[2].add * w.z;
    gOut.tintWeight = gIn[0].tintWeight * w.x + gIn[1].tintWeight * w.y
        + gIn[2].tintWeight * w.z;
    gOut.colorSub =
        gIn[0].colorSub * w.x + gIn[1].colorSub * w.y + gIn[2].colorSub * w.z;
    gOut.addSub =
        gIn[0].addSub * w.x + gIn[1].addSub * w.y + gIn[2].addSub * w.z;
    gOut.worldY =
        gIn[0].worldY * w.x + gIn[1].worldY * w.y + gIn[2].worldY * w.z;
    gOut.affineUV =
        gIn[0].affineUV * w.x + gIn[1].affineUV * w.y + gIn[2].affineUV * w.z;

    // The flat members hold one value for the whole face.
    gOut.slot = gIn[0].slot;
    gOut.flags = gIn[0].flags;
    gOut.texLayer = gIn[0].texLayer;
    gOut.atlasSize = gIn[0].atlasSize;
    gOut.reflectivity = gIn[0].reflectivity;
    EmitVertex();
}

// Row i of the grid holds i + 1 points, from the first corner down to the
// edge that joins the other two.
vec3 gridWeights(int i, int j, float inv)
{
    return vec3(
        1.0 - float(i) * inv, float(i - j) * inv, float(j) * inv);
}

void main(void)
{
    int level = subdivideLevel();
    float inv = 1.0 / float(level);
    for (int i = 0; i < level; i++) {
        for (int j = 0; j <= i; j++) {
            emitAt(gridWeights(i, j, inv));
            emitAt(gridWeights(i + 1, j, inv));
        }
        emitAt(gridWeights(i + 1, i + 1, inv));
        EndPrimitive();
    }
}

#elif defined(FRAGMENT)

uniform sampler2DArray uTexAtlas;
uniform sampler2D uTexEnvMap;
uniform bool uDiscardAlpha;

#if TR_VERSION >= 4
// TR4 reflections sample the env map out of the atlas, from the sprite the OG
// uses for it. uEnvMapLayer is < 0 when the level has no such sprite.
uniform vec2 uEnvMapUV0;
uniform vec2 uEnvMapUV1;
uniform int uEnvMapLayer;
#endif

in GeomData {
    MESH_VARYINGS
} gIn;
out vec4 outColor;

vec4 applyFog(vec4 color, float dist)
{
    // Leaves PlayStation depth cue on the vertex color.
    if (uPS1FogEnabled != 0) {
        return color;
    }
    float fogFactor = clamp(
        (dist - uFogDistance.x) / (uFogDistance.y - uFogDistance.x), 0.0, 1.0);
    return mix(color, uFogColor, fogFactor);
}

// Volumetric fog bulbs (port of the OG OmniEffect/OmniFog,
// polyinsert.cpp:530-688), evaluated per fragment in view space. Level
// bulbs push the fragment toward the fog color; FX bulbs (e.g. underwater
// flares) add colored light. TR4 levels carry bulbs of their own; the other
// games see the ones a script asks for.
#define MAX_FOG_BULBS 10

struct FogBulb {
    vec4 pos;    // view space center; w = distance to camera
    vec4 edge;   // view space sphere edge point toward camera; w = sqrad
    vec4 color;  // rgb 0..1; w = density (0..255)
    vec4 params; // x = 1 / sqrad, y = 1 for FX bulbs
};

layout(std140) uniform FogBulbs {
    int uNumFogBulbs;
    FogBulb uFogBulbs[MAX_FOG_BULBS];
};

vec4 applyFogBulbs(vec4 color)
{
    vec3 fxAdd = vec3(0.0);
    float fogAmount = 0.0;
    vec3 fogColor = vec3(0.0);
    for (int i = 0; i < uNumFogBulbs; i++) {
        vec3 p = gIn.eyePos.xyz;
        // Fragments beyond the bulb are pulled back onto the eye-sphere at
        // the bulb's distance, so the fog reads as a volume. The OG projects
        // onto the plane z == dist instead, which is discontinuous across
        // z == pos.z for off-center bulbs - harmless when interpolated from
        // vertices, but a hard seam across nearby geometry per-fragment.
        float fragDist = length(p);
        if (fragDist > uFogBulbs[i].pos.w) {
            p *= uFogBulbs[i].pos.w / fragDist;
        }
        vec3 dP = p - uFogBulbs[i].pos.xyz;
        vec3 dV = uFogBulbs[i].edge.xyz - uFogBulbs[i].pos.xyz;
        float dv2 = dot(dV, dV);
        if (dv2 <= 0.0) {
            continue;
        }
        float t = dot(dP, dV) / dv2;
        if (t < -1.0) {
            continue;
        }
        if (t > 0.0) {
            dP -= t * dV;
        }
        float d2 = dot(dP, dP);
        if (d2 <= 0.0 || d2 >= uFogBulbs[i].edge.w) {
            continue;
        }
        float density = uFogBulbs[i].color.w;
        float val = d2 * uFogBulbs[i].params.x * density;
        if (uFogBulbs[i].params.y != 0.0) {
            fxAdd += (density - val) * uFogBulbs[i].color.rgb * (1.0 / 256.0);
        } else {
            fogAmount += (density - val) * (1.0 / 255.0);
            // Level bulbs blend toward the OG hardware fog color.
            fogColor = uFogBulbs[i].color.rgb;
        }
    }
    // The framebuffer blend is premultiplied alpha, so scale the bulb
    // contributions by the coverage. Translucent fragments - e.g. bilinear
    // filtered chroma-key edges on the horizon mesh - would otherwise
    // receive full-strength fog and ring against the bulb-less sky layers
    // behind them.
    color.rgb = clamp(color.rgb + fxAdd * color.a, 0.0, 1.0);
    color.rgb = mix(color.rgb, fogColor * color.a, clamp(fogAmount, 0.0, 1.0));
    return color;
}

void main(void) {
    gSlot = gIn.slot;
    // How much of the fragment lies under the water surface, from 0 above it
    // to 1 below it. Y grows downwards, so a fragment past the line is the
    // one under the water. Without a surface to cut it, the whole fragment
    // counts as under the water.
    float submerged = gIn.tintWeight;
    if (I_WATER_LINE_ENABLED) {
#if TR_VERSION >= 4
        // TR4 takes the color up over a band about the surface rather than at
        // it, because a hard line reads as a seam against the water's own
        // movement.
        submerged = smoothstep(
            I_WATER_LINE - WATER_LINE_FEATHER * 0.5,
            I_WATER_LINE + WATER_LINE_FEATHER * 0.5, gIn.worldY);
#else
        submerged = step(I_WATER_LINE, gIn.worldY);
#endif
        submerged *= gIn.tintWeight;
    }

    vec4 texColor = gIn.color;
    vec3 lightAdd = gIn.add;
    if (I_SUBMERGED_AMBIENT_ENABLED) {
        texColor.rgb = mix(texColor.rgb, gIn.colorSub, submerged);
        lightAdd = mix(lightAdd, gIn.addSub, submerged);
    }

    // Texturing and base color
    if (gIn.texLayer >= 0) {
        // The PlayStation had no perspective correction: it interpolated the
        // texture coordinates flat across the face, which is what warps its
        // textures as the camera turns.
        bool affine = uAffineMappingEnabled != 0;
        vec2 uv = affine ? gIn.affineUV.xy : gIn.texUV;
        vec3 texCoords = vec3(uv.x, uv.y, gIn.texLayer);
        if (uTrapezoidFilterEnabled != 0) {
            texCoords.xy /= affine ? gIn.affineUV.zw : gIn.trapezoidRatios;
        }
        if ((gIn.flags & VERT_TEX_WRAP) == 0u) {
            texCoords.xy = clampTexAtlas(texCoords.xy, gIn.atlasSize);
        }
        texColor *= texture(uTexAtlas, texCoords);
    } else {
        texColor.rgb *= texColor.a;
    }

    // Overbright lighting excess, added after texturing (OG specular).
    texColor.rgb += lightAdd;

    // Clips saturating light before fog and bulb blending.
    if (uLightingCurve == LIGHTING_CURVE_SATURATE) {
        texColor.rgb = min(texColor.rgb, vec3(1.0));
    }

    bool reflective =
        (gIn.flags & VERT_REFLECTIVE) != 0u && uReflectionsEnabled != 0;

#if TR_VERSION >= 4
    // The normal maps across the env map window. No y-flip here: view space
    // is Y-down (the GL/D3D flip lives in the projection) and the atlas is
    // stored top row first, so this already matches the OG.
    //
    // The OG draws the reflection as a second, purely additive pass over the
    // face (drawtype 2 = ONE/ONE), textured with the env map and modulated by
    // the lit vertex color scaled by the face's reflectivity. The face's own
    // texture takes no part in it, so the reflection covers the chroma-keyed
    // parts of the face as well.
    vec3 reflection = vec3(0.0);
    if (reflective && uEnvMapLayer >= 0) {
        vec2 env_uv = mix(uEnvMapUV0, uEnvMapUV1, gIn.normal.xy * 0.5 + 0.5);
        vec3 env_color = texture(uTexAtlas, vec3(env_uv, uEnvMapLayer)).rgb;
        reflection = env_color * gIn.color.rgb * gIn.reflectivity;
    }

    // A chroma-keyed fragment carrying a reflection survives, except in the
    // passes that write depth, where it would hide the geometry behind the
    // face.
    bool keep_chroma_key = reflection != vec3(0.0) && !uDiscardAlpha;
#else
    bool keep_chroma_key = false;
#endif

    // Discard chroma-keyed texels, and transparent ones in the opaque pass.
#ifndef NO_ALPHA_DISCARD
    if (!keep_chroma_key
        && (texColor.a <= 0.0
            || (uDiscardAlpha && texColor.a < 0.99
                && (gIn.flags & VERT_NO_ALPHA_DISCARD) == 0u))) {
        discard;
    }
#endif

    // Reflections
#if TR_VERSION >= 4
    if (reflection != vec3(0.0)) {
        // The additive blend scales the color by its alpha, while the OG
        // reflection pass draws at full strength.
        if ((gIn.flags & VERT_ADDITIVE) != 0u) {
            texColor.a = 1.0;
        }
        texColor.rgb += reflection;
    }
#else
    if (reflective) {
        // The env map is a capture of the framebuffer, whose origin is at the
        // bottom left, hence the flip.
        vec2 env_uv = normalize(gIn.normal).xy * 0.5 + 0.5;
        env_uv.y = 1.0 - env_uv.y;
        texColor.rgb *= texture(uTexEnvMap, env_uv).rgb * 2.0;
    }
#endif

    // Fog
    if ((gIn.flags & (VERT_NO_FOG | VERT_NO_LIGHTING)) == 0u
        && uLightingEnabled != 0) {
        texColor = applyFog(texColor, fogDistance(gIn.eyePos.xyz));
        // The OG skips fog bulbs on additive polys (AddTriClippedSorted
        // excludes drawtypes 2 and 5 from OmniFog).
        if ((gIn.flags & VERT_ADDITIVE) == 0u) {
            texColor = applyFogBulbs(texColor);
        }
    }

    texColor.rgb *= uBrightnessMultiplier;
    // The framebuffer blend is premultiplied alpha, so the color carries the
    // coverage: fading a fragment out scales both, and the color a second time
    // by the alpha it is premultiplied against.
    if (I_WATER_LINE_ENABLED) {
        texColor.rgb *= mix(vec3(1.0), I_TINT.rgb, submerged);
        texColor.a *= I_TINT.a;
    } else if (uLightingCurve == LIGHTING_CURVE_SATURATE) {
        texColor.a *= I_TINT.a;
    } else {
        texColor.rgb *= mix(vec3(1.0), I_TINT.rgb, gIn.tintWeight);
        texColor.a *= I_TINT.a;
    }
    texColor.rgb *= I_TINT.a;

    outColor = texColor;
}

#endif
