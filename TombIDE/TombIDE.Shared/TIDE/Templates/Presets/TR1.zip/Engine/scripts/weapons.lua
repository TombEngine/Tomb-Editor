require("common.weapons")
