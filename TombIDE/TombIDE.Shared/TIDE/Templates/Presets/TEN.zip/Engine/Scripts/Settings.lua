-- TombEngine settings file
-- WARNING: Bad values could make your game unplayable; please follow reference guide attentively.

local Flow = TEN.Flow

local settings = Flow.Settings.new()

	settings.Animations.backJumpTurn = false
	settings.Animations.crouchRoll = true
	settings.Animations.crawlspaceSwandive = true
	settings.Animations.sprintJump = false
	settings.Animations.ledgeJumps = false
	settings.Animations.poseTimeout = 0
	settings.Animations.internalBlendDuration = 4
	
	settings.Camera.binocularLightColor = Color(192, 192, 96)
	settings.Camera.lasersightLightColor = Color(255, 0, 0)
	settings.Camera.objectCollision = true

	settings.Effects.bloodColor = Color(255, 0, 0)
	settings.Effects.bloodBlendMode = TEN.Effects.BlendID.ADDITIVE
	settings.Effects.bloodSize = 1.0
	settings.Effects.ricochetColor = Color(255, 153, 0)
	settings.Effects.ricochetCount = 8
	settings.Effects.ricochetSound = true
	settings.Effects.explosionShockwave = true
	settings.Effects.waterEffectStrength = 1.0
	settings.Effects.waterEffectDepth = 3072.0
	
	settings.Flare.color = Color(128, 64, 0)
	settings.Flare.offset = Vec3(0, 0, 41)
	settings.Flare.range = 9
	settings.Flare.timeout = 60
	settings.Flare.lensflareBrightness = 0.5
	settings.Flare.muzzleGlow = false
	settings.Flare.sparks = true
	settings.Flare.smoke = true
	settings.Flare.flicker = true
	settings.Flare.pickupCount = 12
	
	settings.Gameplay.enableInventory = true
	settings.Gameplay.killPoisonedEnemies = true
	settings.Gameplay.setEnemiesOnFireWithWeapons = true
	settings.Gameplay.setEnemiesOnFireWithDeathFlag = true
	settings.Gameplay.targetObjectOcclusion = true

	settings.Graphics.ambientOcclusion = true
	settings.Graphics.flameHeatHaze = true
	settings.Graphics.skinning = true
	
	settings.Hud.statusBars = true
	settings.Hud.loadingBar = true
	settings.Hud.speedometer = true
	settings.Hud.pickupNotifier = true
	settings.Hud.interactionHighlighter = true
	settings.Hud.targetHighlighter = true
	
	settings.Pathfinding.mode = PathfindingMode.ASTAR
	settings.Pathfinding.searchDepth = 5
	settings.Pathfinding.escapeDistance = 5120
	settings.Pathfinding.stalkDistance = 3072
	settings.Pathfinding.predictionFactor = 15.0
	settings.Pathfinding.collisionPenaltyThreshold = 1
	settings.Pathfinding.collisionPenaltyCooldown = 6
	settings.Pathfinding.moveableAvoidance = false
	settings.Pathfinding.staticMeshAvoidance = false
	settings.Pathfinding.verticalGeometryAvoidance = true
	settings.Pathfinding.waterSurfaceAvoidance = true
	settings.Pathfinding.verticalMovementSmoothing = true
	
	settings.Physics.gravity = 6
	settings.Physics.swimVelocity = 50
	
	settings.System.discordIntegration = true
	settings.System.errorMode = Flow.ErrorMode.WARN
	settings.System.fastReload = true
	settings.System.multithreaded = true
	settings.System.variableFloodProtectionTimeLimit = 1000
	settings.System.variableFloodProtectionOverallLimit = 10000
	
	settings.UI.headerTextColor = Color(216, 117, 49)
	settings.UI.optionTextColor = Color(240, 220, 32)
	settings.UI.plainTextColor = Color(255, 255, 255)
	settings.UI.disabledTextColor = Color(128, 128, 128)
	settings.UI.shadowTextColor = Color(0, 0, 0)
	settings.UI.menuBackgroundBlur = 0.15
	settings.UI.systemTextScale = 1.0
	settings.UI.titleLogoPosition = Vec2(50, 20)
	settings.UI.titleLogoScale = 0.38
	settings.UI.titleLogoColor = Color(255, 255, 255)
	settings.UI.titleMenuPosition = Vec2(50, 66)
	settings.UI.titleMenuScale = 1.0
	settings.UI.titleMenuAlignment = Strings.DisplayStringOption.CENTER
	
	-- Hair[1] is normal player hair. Types [2] and [3] are for left and right young Lara hair.
	
	settings.Hair[1].rootMesh = 14
	settings.Hair[1].offset = Vec3(-4, -4, -48)
	settings.Hair[1].indices = { 37, 39, 40, 38 }
	
	settings.Hair[2].rootMesh = 14
	settings.Hair[2].offset = Vec3(-48, -48, -50)
	settings.Hair[2].indices = { 79, 78, 76, 77 }
	
	settings.Hair[3].rootMesh = 14
	settings.Hair[3].offset = Vec3(48, -48, -50)
	settings.Hair[3].indices = { 68, 69, 70, 71 }

	-- Not all weapon settings are applicable to every weapon. Those which are not applicable
	-- for a particular weapon type are omitted. See documentation for more details.
	
	settings.Weapons[WeaponType.PISTOLS].accuracy = 8
	settings.Weapons[WeaponType.PISTOLS].targetingDistance = 8192
	settings.Weapons[WeaponType.PISTOLS].interval = 9
	settings.Weapons[WeaponType.PISTOLS].waterLevel = 650
	settings.Weapons[WeaponType.PISTOLS].flashDuration = 3
	settings.Weapons[WeaponType.PISTOLS].flashRange = 9
	settings.Weapons[WeaponType.PISTOLS].flashColor = Color(192, 128, 0)
	settings.Weapons[WeaponType.PISTOLS].damage = 1
	settings.Weapons[WeaponType.PISTOLS].smoke = true
	settings.Weapons[WeaponType.PISTOLS].shell = true
	settings.Weapons[WeaponType.PISTOLS].muzzleFlash = true
	settings.Weapons[WeaponType.PISTOLS].muzzleGlow = false
	settings.Weapons[WeaponType.PISTOLS].muzzleOffset = Vec3(0, 120, 30)
	settings.Weapons[WeaponType.PISTOLS].colorizeMuzzleFlash = false
	settings.Weapons[WeaponType.PISTOLS].pickupCount = 30
	
	settings.Weapons[WeaponType.REVOLVER].accuracy = 8
	settings.Weapons[WeaponType.REVOLVER].targetingDistance = 8192
	settings.Weapons[WeaponType.REVOLVER].interval = 16
	settings.Weapons[WeaponType.REVOLVER].waterLevel = 650
	settings.Weapons[WeaponType.REVOLVER].flashDuration = 3
	settings.Weapons[WeaponType.REVOLVER].flashRange = 9
	settings.Weapons[WeaponType.REVOLVER].flashColor = Color(192, 128, 0)
	settings.Weapons[WeaponType.REVOLVER].damage = 21
	settings.Weapons[WeaponType.REVOLVER].alternateDamage = 21
	settings.Weapons[WeaponType.REVOLVER].smoke = true
	settings.Weapons[WeaponType.REVOLVER].shell = false
	settings.Weapons[WeaponType.REVOLVER].muzzleFlash = true
	settings.Weapons[WeaponType.REVOLVER].muzzleGlow = false
	settings.Weapons[WeaponType.REVOLVER].muzzleOffset = Vec3(-10, 130, 65)
	settings.Weapons[WeaponType.REVOLVER].colorizeMuzzleFlash = false
	settings.Weapons[WeaponType.REVOLVER].pickupCount = 6
	
	settings.Weapons[WeaponType.UZIS].accuracy = 8
	settings.Weapons[WeaponType.UZIS].targetingDistance = 8192
	settings.Weapons[WeaponType.UZIS].interval = 3
	settings.Weapons[WeaponType.UZIS].waterLevel = 650
	settings.Weapons[WeaponType.UZIS].flashDuration = 2
	settings.Weapons[WeaponType.UZIS].flashRange = 9
	settings.Weapons[WeaponType.UZIS].flashColor = Color(192, 128, 0)
	settings.Weapons[WeaponType.UZIS].damage = 1
	settings.Weapons[WeaponType.UZIS].smoke = true
	settings.Weapons[WeaponType.UZIS].shell = true
	settings.Weapons[WeaponType.UZIS].muzzleFlash = true
	settings.Weapons[WeaponType.UZIS].muzzleGlow = false
	settings.Weapons[WeaponType.UZIS].muzzleOffset = Vec3(0, 110, 40)
	settings.Weapons[WeaponType.UZIS].colorizeMuzzleFlash = false
	settings.Weapons[WeaponType.UZIS].pickupCount = 30
	
	settings.Weapons[WeaponType.SHOTGUN].accuracy = 10
	settings.Weapons[WeaponType.SHOTGUN].targetingDistance = 8192
	settings.Weapons[WeaponType.SHOTGUN].waterLevel = 500
	settings.Weapons[WeaponType.SHOTGUN].flashDuration = 3
	settings.Weapons[WeaponType.SHOTGUN].flashRange = 12
	settings.Weapons[WeaponType.SHOTGUN].flashColor = Color(192, 128, 0)
	settings.Weapons[WeaponType.SHOTGUN].damage = 3
	settings.Weapons[WeaponType.SHOTGUN].smoke = true
	settings.Weapons[WeaponType.SHOTGUN].shell = true
	settings.Weapons[WeaponType.SHOTGUN].muzzleFlash = false
	settings.Weapons[WeaponType.SHOTGUN].muzzleGlow = false
	settings.Weapons[WeaponType.SHOTGUN].muzzleOffset = Vec3(0, 210, 40)
	settings.Weapons[WeaponType.SHOTGUN].colorizeMuzzleFlash = false
	settings.Weapons[WeaponType.SHOTGUN].pickupCount = 6
	
	settings.Weapons[WeaponType.HK].accuracy = 4
	settings.Weapons[WeaponType.HK].targetingDistance = 12288
	settings.Weapons[WeaponType.HK].waterLevel = 500
	settings.Weapons[WeaponType.HK].flashDuration = 2
	settings.Weapons[WeaponType.HK].flashRange = 12
	settings.Weapons[WeaponType.HK].flashColor = Color(192, 128, 0)
	settings.Weapons[WeaponType.HK].damage = 4
	settings.Weapons[WeaponType.HK].alternateDamage = 4
	settings.Weapons[WeaponType.HK].smoke = true
	settings.Weapons[WeaponType.HK].shell = true
	settings.Weapons[WeaponType.HK].muzzleFlash = true
	settings.Weapons[WeaponType.HK].muzzleGlow = false
	settings.Weapons[WeaponType.HK].muzzleOffset = Vec3(0, 220, 102)
	settings.Weapons[WeaponType.HK].colorizeMuzzleFlash = false
	settings.Weapons[WeaponType.HK].pickupCount = 30
	
	settings.Weapons[WeaponType.CROSSBOW].targetingDistance = 8192
	settings.Weapons[WeaponType.CROSSBOW].waterLevel = 500
	settings.Weapons[WeaponType.CROSSBOW].damage = 5
	settings.Weapons[WeaponType.CROSSBOW].alternateDamage = 20
	settings.Weapons[WeaponType.CROSSBOW].pickupCount = 10
	
	settings.Weapons[WeaponType.GRENADE_LAUNCHER].targetingDistance = 8192
	settings.Weapons[WeaponType.GRENADE_LAUNCHER].waterLevel = 500
	settings.Weapons[WeaponType.GRENADE_LAUNCHER].damage = 20
	settings.Weapons[WeaponType.GRENADE_LAUNCHER].smoke = true
	settings.Weapons[WeaponType.GRENADE_LAUNCHER].pickupCount = 10
	
	settings.Weapons[WeaponType.ROCKET_LAUNCHER].targetingDistance = 8192
	settings.Weapons[WeaponType.ROCKET_LAUNCHER].waterLevel = 500
	settings.Weapons[WeaponType.ROCKET_LAUNCHER].damage = 30
	settings.Weapons[WeaponType.ROCKET_LAUNCHER].smoke = true
	settings.Weapons[WeaponType.ROCKET_LAUNCHER].pickupCount = 1
	
	settings.Weapons[WeaponType.HARPOON_GUN].targetingDistance = 8192
	settings.Weapons[WeaponType.HARPOON_GUN].damage = 6
	settings.Weapons[WeaponType.HARPOON_GUN].pickupCount = 10
	
Flow.SetSettings(settings)
